package main.domain;

public enum GameStatus {
    WON, DRAW, RUNNING
}
