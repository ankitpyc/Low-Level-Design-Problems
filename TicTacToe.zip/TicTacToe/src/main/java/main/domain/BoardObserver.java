package main.domain;

public interface BoardObserver {

    public void observe(BoardStatus boardStatus);

}
