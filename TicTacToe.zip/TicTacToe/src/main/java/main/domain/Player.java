package main.domain;

public class Player {
    public String playerName;
    public PlayerMove move;

    public Player(String playerName) {
        this.playerName = playerName;
    }
}
