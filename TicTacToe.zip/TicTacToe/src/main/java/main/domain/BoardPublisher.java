package main.domain;

public interface BoardPublisher {

    public void notifyOnStatusChange(BoardStatus status);

}
